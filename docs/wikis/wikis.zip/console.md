# 控制台的使用
## 本文作者：youpaishidifu

# menu:
1. 前往控制台
2. 操纵控制台

## 前往控制台
打开时钟菜单，点击`红石`按钮，立即前往控制台

## 操纵控制台
根据各命令方块上的标识标牌，可以操作当前世界内游戏环境
比如说，您需要将当前游戏时间，调整为白天，就在控制台区域，按下`白天`的按钮，即可将当前游戏时间调整为白天
![](https://img.yunr.us.kg/api/cfile/AgACAgUAAyEGAASO2xA4AAMPZvQXHFfhktAJn__SgKm4xzBFX5UAAhO-MRuUYaBXYeSyvgcKaqkBAAMCAAN3AAM2BA)

**如若有未标记的，请勿操纵该命令方块，否则造成的踢出拉黑封禁等一切后果，需要您承担** 