# 袭击塔的使用
## 制作者：19kdSB    本文作者：youpaishidifu

# menu
## 前往袭击塔
## 使用袭击塔
## 领取战利品
---

## 前往袭击塔
打开时钟菜单，进入`传送菜单`-`袭击塔`，单击即可自动前往袭击塔

## 使用袭击塔
### 上去塔
![](https://openai-75050.gzc.vod.tencent-cloud.com/openaiassets_bf6c76a2c832973c022ad09bdc4753d4_2579861727316290521.png)
传送过来后，从这里上袭击塔

### 战利品领取处
![](https://openai-75050.gzc.vod.tencent-cloud.com/openaiassets_1a20d2effa8c4eaf62f3968dddc44a3d_2579861727316297599.png)
这里是战利品领取处，上来袭击塔后第一个到达的地方

### 袭击塔的工作区域
使用前，需要将开关开启
![](https://openai-75050.gzc.vod.tencent-cloud.com/openaiassets_7e3ec21d3820a6d120025c8e78fd527f_2579861727316300643.png)

旁边有一个一件获取buff的地方，您也可以选择攻击 **“小队长”** 来获取buff
![](https://openai-75050.gzc.vod.tencent-cloud.com/openaiassets_8986b2f12bfdad2e86700aa65cb1c186_2579861727316648269.png)

开关开启，获取buff后，来到侧面，有个入口，从这进入工作区
![](https://openai-75050.gzc.vod.tencent-cloud.com/openaiassets_e6260ab4c963ecff8702542d42815886_2579861727316303954.png)

从这里进去后，走到底，就是袭击塔的工作区域了，所有的灾厄村民，会从上面掉下来，使用带有 **横扫之刃** 的武器攻击他们即可，击杀后，会掉落战利品
![](https://openai-75050.gzc.vod.tencent-cloud.com/openaiassets_9bc27038fed2c5cd4ca53bccb47cce55_2579861727316285275.png)
