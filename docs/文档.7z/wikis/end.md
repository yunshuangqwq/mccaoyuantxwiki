 # 小黑塔的使用
 ## 制作人/本文作者: youpaishidifu

 # menu 
 1. 前往小黑塔
 2. 开始刷经验

## 前往小黑塔
打开菜单，或在聊天框输入指令`dom tp yp的小黑塔`
![](https://img.yunr.us.kg/api/cfile/AgACAgUAAyEGAASO2xA4AAMSZvQYGEjZ-35TfQPb4o0fm9cqrvsAAku-MRuUYaBXH3AX3di6k0YBAAMCAAN3AAM2BA)

从这里下来以后，就是刷经验的地方了

## 开始刷经验
站在这个位置，使用带有**横扫之刃**的大剑，一刀带走一片，然后继续下一片，直到刷到所需的经验等级/装备耐久
![](https://img.yunr.us.kg/api/cfile/AgACAgUAAyEGAASO2xA4AAMTZvQYG8dy4wABxylWD51CoaDpKQMaAAJMvjEblGGgV0Ul4B0GzAGdAQADAgADdwADNgQ)

## 领取末影珍珠
刷完后，所有的末影珍珠会在底下的箱子中完成收集，打开箱子，取走珍珠即可。
![](https://img.yunr.us.kg/api/cfile/AgACAgUAAyEGAASO2xA4AAMQZvQYDjewNWCKAAGwHcLRtao5yq2kAAJJvjEblGGgV7pvVGdbq5-LAQADAgADdwADNgQ)

### 运送末影珍珠至管理员的店铺
将末影珍珠运输至管理员的店铺，您可以获得足额的游戏币回报。需要您手动打包，使用任意颜色潜影盒将末影珍珠存入，然后放置在店铺门口的外卖柜并通知管理员，即可获得游戏币奖励

| 末影珍珠盒数 | 奖励游戏币 |
| :---: | :---: |
| 1 | 5万 |
| 2 | 10万 |
| 3 | 20万 |
| 4 | 30万 |

以此类推，盒数越多，奖励越多！
